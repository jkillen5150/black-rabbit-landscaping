#!/bin/bash

echo "🚀 Deploying Black Rabbit Landscaping to GitHub Pages..."

# Create docs directory if it doesn't exist
mkdir -p docs

# Copy website files to docs directory
echo "📁 Copying website files..."
cp website/index.html docs/
cp website/admin.html docs/

# Copy assets if they exist
if [ -d "assets" ]; then
    echo "📷 Copying assets..."
    cp -r assets docs/
fi

# Create CNAME file for custom domain
echo "🌐 Setting up custom domain..."
echo "blackrabbitllc.org" > docs/CNAME

# Initialize git if not already done
if [ ! -d ".git" ]; then
    echo "🔧 Initializing git repository..."
    git init
    git branch -M main
fi

# Add all files
echo "📦 Adding files to git..."
git add .

# Commit changes
echo "💾 Committing changes..."
git commit -m "Deploy Black Rabbit Landscaping website to GitHub Pages

- Added seasonal theme system with advanced animations
- Integrated quote request form with email notifications
- Google Business verification codes included
- Mobile app download integration
- Professional responsive design for BlackRabbitLLC.org"

echo ""
echo "✅ Files prepared for GitHub deployment!"
echo ""
echo "📋 Next steps:"
echo "1. Create a new repository on GitHub"
echo "2. Copy the git remote add command from GitHub"
echo "3. Run: git remote add origin YOUR_GITHUB_REPO_URL"
echo "4. Run: git push -u origin main"
echo "5. Enable GitHub Pages in repository settings"
echo "6. Configure custom domain: blackrabbitllc.org"
echo ""
echo "📖 See deployment/github-setup-guide.md for detailed instructions"