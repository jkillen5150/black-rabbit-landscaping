#!/bin/bash
# Black Rabbit Landscaping Deployment Script
# Supports multiple deployment strategies

set -e  # Exit on any error

echo "🐰 Black Rabbit Landscaping Deployment Script"
echo "=============================================="

# Parse command line arguments
DEPLOY_TARGET=${1:-"help"}
BUILD_MODE=${2:-"production"}

case $DEPLOY_TARGET in
  "expo")
    echo "📱 Deploying to Expo Web..."
    echo "Installing Expo CLI if needed..."
    npm install -g @expo/cli
    
    echo "Building for web..."
    expo export -p web
    
    echo "Publishing to Expo..."
    expo publish --platform web
    
    echo "✅ Expo deployment complete!"
    echo "Your app is available at: https://expo.dev/@yourusername/black-rabbit-landscaping"
    ;;
    
  "vercel")
    echo "🔺 Deploying to Vercel..."
    echo "Installing Vercel CLI if needed..."
    npm install -g vercel
    
    echo "Building production bundle..."
    npm run build
    
    echo "Deploying to Vercel..."
    vercel --prod
    
    echo "✅ Vercel deployment complete!"
    ;;
    
  "netlify")
    echo "🌐 Deploying to Netlify..."
    echo "Installing Netlify CLI if needed..."
    npm install -g netlify-cli
    
    echo "Building production bundle..."
    npm run build
    
    echo "Deploying to Netlify..."
    netlify deploy --prod --dir=dist
    
    echo "✅ Netlify deployment complete!"
    ;;
    
  "build")
    echo "🏗️ Building for production..."
    
    # Clean previous builds
    rm -rf dist/
    
    # Build React Native Web bundle
    npm run build
    
    echo "✅ Production build complete in ./dist/"
    echo "Ready for static hosting deployment"
    ;;
    
  "local")
    echo "🖥️ Starting local development server..."
    echo "Installing dependencies..."
    npm install
    
    echo "Starting webpack dev server..."
    npm run dev
    ;;
    
  "app-store")
    echo "📲 Building for App Stores..."
    echo "This requires Expo account setup and developer certificates"
    
    echo "Building iOS app..."
    expo build:ios --type app-store
    
    echo "Building Android app..."
    expo build:android --type app-bundle
    
    echo "✅ App store builds initiated!"
    echo "Check your Expo dashboard for build status"
    ;;
    
  "backend")
    echo "🔧 Setting up backend server..."
    
    cd backend/
    
    echo "Installing backend dependencies..."
    npm install
    
    echo "Starting backend server..."
    if [ "$BUILD_MODE" = "development" ]; then
      npm run dev
    else
      npm start
    fi
    ;;
    
  "help"|*)
    echo "Usage: ./deploy.sh [target] [mode]"
    echo ""
    echo "Deployment Targets:"
    echo "  expo        - Deploy to Expo web hosting (free)"
    echo "  vercel      - Deploy to Vercel (free tier available)"
    echo "  netlify     - Deploy to Netlify (free tier available)"
    echo "  build       - Build production bundle for manual hosting"
    echo "  local       - Start local development server"
    echo "  app-store   - Build for iOS/Android app stores"
    echo "  backend     - Start backend API server"
    echo "  help        - Show this help message"
    echo ""
    echo "Build Modes:"
    echo "  production  - Optimized production build (default)"
    echo "  development - Development build with debugging"
    echo ""
    echo "Examples:"
    echo "  ./deploy.sh expo              # Deploy to Expo"
    echo "  ./deploy.sh vercel            # Deploy to Vercel"
    echo "  ./deploy.sh local development # Local dev server"
    echo "  ./deploy.sh backend           # Start API server"
    ;;
esac