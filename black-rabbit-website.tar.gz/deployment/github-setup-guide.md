# GitHub Pages Deployment Guide for BlackRabbitLLC.org

## Quick Setup Steps

### 1. Create GitHub Repository
1. Go to [GitHub.com](https://github.com) and create a new repository
2. Name it: `black-rabbit-landscaping` or `blackrabbitllc-website`
3. Make it **Public** (required for free GitHub Pages)
4. Don't initialize with README (we'll push our existing code)

### 2. Push Code to GitHub
```bash
# Initialize git repository (if not already done)
git init

# Add all files
git add .

# Commit files
git commit -m "Initial website deployment for BlackRabbitLLC.org"

# Add GitHub repository as remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/black-rabbit-landscaping.git

# Push to GitHub
git push -u origin main
```

### 3. Enable GitHub Pages
1. Go to your repository on GitHub
2. Click **Settings** tab
3. Scroll down to **Pages** section in the left sidebar
4. Under **Source**, select **GitHub Actions**
5. The deployment will start automatically

### 4. Configure Custom Domain
1. In the **Pages** settings, under **Custom domain**
2. Enter: `blackrabbitllc.org`
3. Click **Save**
4. Wait for DNS check (may take a few minutes)

### 5. Update DNS Records at Name.com
In your Name.com domain settings, add these DNS records:

**A Records (Point to GitHub Pages IPs):**
```
Type: A
Host: @
Value: 185.199.108.153

Type: A  
Host: @
Value: 185.199.109.153

Type: A
Host: @
Value: 185.199.110.153

Type: A
Host: @
Value: 185.199.111.153
```

**CNAME Record (for www subdomain):**
```
Type: CNAME
Host: www
Value: YOUR_USERNAME.github.io
```

### 6. Verify Deployment
1. Wait 5-10 minutes for DNS propagation
2. Visit `https://blackrabbitllc.org`
3. Your website should be live!

## Automatic Updates

Every time you push changes to the `main` branch, GitHub Actions will automatically:
1. Build the website
2. Deploy to GitHub Pages
3. Update BlackRabbitLLC.org

## Admin Access

Admin panel available at: `https://blackrabbitllc.org/admin.html`

**Credentials:**
- Username: admin@blackrabbitllc.org  
- Password: BlackRabbit2025!

## Troubleshooting

**Domain not working?**
- Check DNS propagation: [whatsmydns.net](https://whatsmydns.net)
- Verify A records point to GitHub Pages IPs
- Ensure CNAME file contains `blackrabbitllc.org`

**Deployment failing?**
- Check Actions tab in GitHub repository
- Verify all files are committed and pushed
- Ensure repository is public

**SSL Certificate issues?**
- GitHub automatically provides SSL
- May take 24-48 hours after domain setup
- Check Pages settings for certificate status

## Next Steps

1. **Google Business Setup**: Use admin credentials to verify domain
2. **Email Integration**: Set up professional email with Google Workspace
3. **Analytics**: Add Google Analytics for visitor tracking
4. **SEO**: Submit sitemap to Google Search Console

---

Need help? Contact support or refer to [GitHub Pages documentation](https://docs.github.com/en/pages).