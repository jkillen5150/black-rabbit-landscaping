# Black Rabbit Landscaping Website

Professional lawn care services in Central Florida. This repository contains the website for BlackRabbitLLC.org.

## Features

- 🌐 **One-page responsive website** optimized for mobile and desktop
- 📱 **Mobile app integration** with download links for iOS and Android
- 📝 **Quote request form** with email notifications
- 🎨 **Seasonal themes** that automatically change based on current month
- 🔍 **Google Business integration** with verification codes
- ⚡ **Fast loading** with optimized assets and modern CSS

## Seasonal Themes

The website automatically applies seasonal backgrounds:
- **Spring** (March-May): Fresh green/blue gradients with springBounce animation
- **Summer** (June-August): Vibrant orange/yellow gradients with summerGlow effects
- **Fall** (September-November): Warm brown/gold gradients with fallDrift animation
- **Winter** (December-February): Cool blue/silver gradients with winterFloat effects

## Business Information

- **Phone**: (407) 951-1663
- **Email**: BlackRabbitLandscaping@gmail.com
- **Service Areas**: Orlando, Altamonte Springs, Winter Park, Longwood, Central Florida
- **Website**: [BlackRabbitLLC.org](https://blackrabbitllc.org)

## Deployment

This site is automatically deployed to GitHub Pages when changes are pushed to the main branch.

## Local Development

To run locally:
```bash
npm install
npm start
```

The website will be available at `http://localhost:5000/website`

---

© 2025 Black Rabbit Landscaping. All rights reserved.